/**
 */
package es.unican.istr.pasys;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mem SQL Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see es.unican.istr.pasys.PasysPackage#getMemSQLService()
 * @model
 * @generated
 */
public interface MemSQLService extends PersistenceService {
} // MemSQLService
