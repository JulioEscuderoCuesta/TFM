/**
 */
package es.unican.istr.pasys;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Workflow Latency Meter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link es.unican.istr.pasys.WorkflowLatencyMeter#getOwner <em>Owner</em>}</li>
 *   <li>{@link es.unican.istr.pasys.WorkflowLatencyMeter#getMetric <em>Metric</em>}</li>
 * </ul>
 *
 * @see es.unican.istr.pasys.PasysPackage#getWorkflowLatencyMeter()
 * @model
 * @generated
 */
public interface WorkflowLatencyMeter extends PrometheusMeter {
	/**
	 * Returns the value of the '<em><b>Owner</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link es.unican.istr.pasys.Workflow#getOwnedMeters <em>Owned Meters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner</em>' container reference.
	 * @see #setOwner(Workflow)
	 * @see es.unican.istr.pasys.PasysPackage#getWorkflowLatencyMeter_Owner()
	 * @see es.unican.istr.pasys.Workflow#getOwnedMeters
	 * @model opposite="ownedMeters" required="true" transient="false"
	 * @generated
	 */
	Workflow getOwner();

	/**
	 * Sets the value of the '{@link es.unican.istr.pasys.WorkflowLatencyMeter#getOwner <em>Owner</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner</em>' container reference.
	 * @see #getOwner()
	 * @generated
	 */
	void setOwner(Workflow value);

	/**
	 * Returns the value of the '<em><b>Metric</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link es.unican.istr.pasys.WorkflowLatency#getMeter <em>Meter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Metric</em>' reference.
	 * @see #setMetric(WorkflowLatency)
	 * @see es.unican.istr.pasys.PasysPackage#getWorkflowLatencyMeter_Metric()
	 * @see es.unican.istr.pasys.WorkflowLatency#getMeter
	 * @model opposite="meter"
	 * @generated
	 */
	WorkflowLatency getMetric();

	/**
	 * Sets the value of the '{@link es.unican.istr.pasys.WorkflowLatencyMeter#getMetric <em>Metric</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Metric</em>' reference.
	 * @see #getMetric()
	 * @generated
	 */
	void setMetric(WorkflowLatency value);

} // WorkflowLatencyMeter
